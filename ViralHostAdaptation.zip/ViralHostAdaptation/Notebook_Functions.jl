function Seed_Model_Dictionary(Model, k) 
    #I pass the model and the index of the viral family, and as additional parameters, if they have to be changed the binary depth and the segment
    D=[] #empty vector of vocabularies
    for n in 1:N_seed
        # I consider for each seed all the three hosts species: avian, human, swine
        M=[]
        [push!(M,Model[j][n]) for j in 1:N_host]
        push!(D, Model_Dictionary(M, k)) #I create a vocabulary for each host 
    end
    return D
end
function Model_Dictionary(M, k) 
    #Creation of the vocabulary which will have as keys ("Viral family", "host species"). Eg.: ("Corona", "human"), ("Corona", "avian"), ("Corona", "swine")).
    #The values will be the set of learnt forces for each mono,di,tri-nucleotides
    D=Dict{Tuple{AbstractString, AbstractString}, MaxEntNucleotideBiases.NucleotideModel}()
    for j in 1:N_host
        D[(v[k], h[j])]=M[j]
    end
return D 
end

function Probabilities_HV1(TestSet, Dictionaries) #Sets of sequences which are wanted to test, models learnt
    Host=[ [] for j in 1:(N_host-1)]
    (typeof(TestSet) == String) ? (pre_seqs_dna = [TestSet]) : (pre_seqs_dna = TestSet)
    TestSet = Main.MaxEntNucleotideBiases._preprocess_seqs(pre_seqs_dna)
    L=length(TestSet) #number of sequences considered
    for n in 1:N_seed #I avarage results over the three seeds
            p_host=[[] for j in 1:(N_host-1)]
            for l in 1:L
                Predictions=predict_host_givenvirus(convert(AbstractString, TestSet[l]), Dictionaries[n]) 
                sorting_predictions(p_host,Predictions, N_host, h, l)
            end

            [push!(Host[j], p_host[j]) for j in 1:(N_host-1)]
    end
    Prob_Host=[ vcat(zeros(1, L)...) for j in 1:(N_host)]
    #Avaraging
    for n in 1:N_seed
        [Prob_Host[j].+=Host[j][n]./N_seed for j in 1:(N_host-1)]
    end
    # Due to normazability considtions
    Prob_Host[end]= 1 .- reduce((x, y) -> x .+ y, Prob_Host[1:end-1]) 
    return Prob_Host
end
function sorting_predictions(prob,Pred, N, label, l)
    for (species, value) in Pred
        for jk in 1:(N-1)
            if species == label[jk]
                if label==h #If i pass the label of hosts
                    push!(prob[jk], value) # I save the probabilities assigned of the sequence i to swine
                else
                    prob[jk][l]+=value
                end
            end
        end
    end
    return prob
end    

function Plot_Seqs_Probabilities(N, Prob, colors, labels)
    L=length(Prob[1]) 
    probabilities =[]
    for l in 1:L
        c=[]
        for jk in 1:N
            push!(c, Prob[jk][l])
        end
        push!(probabilities , c)
    end
    events = ["Sequence $l" for l in 1:L]
    fig, ax = plt.subplots(figsize=(10, 5))
    for l in 1:L
        bottom = 0
        for j in 1:N
            ax.bar(events[l], probabilities[l][j], bottom=bottom, color=colors[j], width=1)
            
            bottom += probabilities[l][j]
        end
    end
    plt.ylim([0, 1])
    plt.title("Plot example", size=15)
    plt.ylabel("Hosts Probability", size=13)
    #Customize ticks
        ticks=vcat([1:L-1]...).-0.5 #Can add separation, labeles customizing ticks
    for tick in ticks 
        axvline(tick, color="firebrick", linestyle="-.") 
    end
    for (color, label) in zip(colors, labels)
        plt.plot([], [], color=color, label=label)
    end
    plt.legend()
    return gcf()
end





function Seed_Model_Dictionary_HV(Model; mm=1, verbose::Bool) 
    #I pass the model and the index of the viral family, and as additional parameters, if they have to be changed the binary depth and the segment
    D=[] #empty vector of vocabularies
 
    for n in 1:N_seed
        DD=[]
        for k in 1:N_virus
            # I consider for each seed all the three hosts species: avian, human, swine
            M=[]
            if verbose==true
                [push!(M, Model[j][k][mm][n]) for j in 1:N_host]
            else
                [push!(M, Model[j][k][n]) for j in 1:N_host]
                
            end
            push!(DD, Model_Dictionary(M, k)) #I create a vocabulary for each host 
        end
        push!(D, DD)
    end
    return merge_Dictionaries(D)
end
function merge_Dictionaries(Dictionaries)
    D=[]
    for n in 1:N_seed
        merged_dict=Dict{Tuple{AbstractString, AbstractString}, MaxEntNucleotideBiases.NucleotideModel}()
        for d in Dictionaries[n]
            merge!(merged_dict, d)
        end
        push!(D, merged_dict)
    end
    return D
end




function Probabilities_HV2(TestSet, Dictionaries; verbose::Bool) #Sets of sequences which are wanted to test, models learnt
    Host=[ [] for j in 1:(N_host-1)]
    Virus=[[] for k in 1:(N_virus-1)]
    (typeof(TestSet) == String) ? (pre_seqs_dna = [TestSet]) : (pre_seqs_dna = TestSet)
    TestSet = Main.MaxEntNucleotideBiases._preprocess_seqs(pre_seqs_dna)
    L=length(TestSet) #number of sequences considered
    for n in 1:N_seed #I avarage results over the three seeds
            p_host=[[] for j in 1:(N_host-1)]
            p_virus=[vcat(zeros(1, L)...) for k in 1:(N_virus-1)]
            for l in 1:L
                Pred_Host, Pred_Virus=predict_host_virushost(convert(AbstractString, TestSet[l]), Dictionaries[n]; output_best_viruses=true)
                sorting_predictions(p_host,Pred_Host, N_host, h, l)
                sorting_predictions(p_virus,Pred_Virus, N_virus, v, l) 
            end
            [push!(Host[j], p_host[j]) for j in 1:(N_host-1)]
            [push!(Virus[k], p_virus[k]) for k in 1:(N_virus-1)]
    end
    Prob_Host=[vcat(zeros(1, L)...) for j in 1:(N_host)]
    Prob_Virus=[vcat(zeros(1, L)...) for k in 1:(N_virus)]
    #Avaraging
    for n in 1:N_seed
        [Prob_Host[j].+=Host[j][n]./N_seed for j in 1:(N_host-1)]
        [Prob_Virus[k].+=Virus[k][n]./N_seed for k in 1:(N_virus-1)]
    end
    # Due to normazability considtions
    Prob_Host[end]= 1 .- reduce((x, y) -> x .+ y, Prob_Host[1:end-1]) 
    Prob_Virus[end]= 1 .- reduce((x, y) -> x .+ y, Prob_Virus[1:end-1])
    if verbose
        return Prob_Host, Prob_Virus
    else
        return Prob_Host
    end
end


function Seed_Model_Dictionary_H(Model; mm=1, verbose::Bool) 
    #I pass the model and the index of the viral family, and as additional parameters, if they have to be changed the binary depth and the segment
    D=[] #empty vector of vocabularies
    for n in 1:N_seed
        # I consider for each seed all the three hosts species: avian, human, swine
        M=[]
        if verbose==true
            [push!(M, Model[j][mm][n]) for j in 1:N_host]
        else
            [push!(M, Model[j][n]) for j in 1:N_host]
        end
        push!(D, Model_Dictionary_H(M)) #I create a vocabulary for each host 
        
    end
    return D
end
function Model_Dictionary_H(M) 
    #Creation of the vocabulary which will have as keys ("Viral family", "host species"). Eg.: ("Corona", "human"), ("Corona", "avian"), ("Corona", "swine")).
    #The values will be the set of learnt forces for each mono,di,tri-nucleotides
    D=Dict{String, MaxEntNucleotideBiases.NucleotideModel}()
    for j in 1:N_host
        D[h[j]]=M[j]
    end
return D 
end

function Probabilities_H(TestSet, Dictionaries) #Sets of sequences which are wanted to test, models learnt
    Host=[ [] for j in 1:(N_host-1)]
    (typeof(TestSet) == String) ? (pre_seqs_dna = [TestSet]) : (pre_seqs_dna = TestSet)
    TestSet = Main.MaxEntNucleotideBiases._preprocess_seqs(pre_seqs_dna)
    L=length(TestSet) #number of sequences considered
    for n in 1:N_seed #I avarage results over the three seeds
            p_host=[[] for j in 1:(N_host-1)]
            p_virus=[vcat(zeros(1, L)...) for k in 1:(N_virus-1)]
            for l in 1:L
                Predictions=predict_host_hostonly(convert(AbstractString, TestSet[l]), Dictionaries[n]) 
                sorting_predictions(p_host,Predictions, N_host, h, l)
            end
            [push!(Host[j], p_host[j]) for j in 1:(N_host-1)]
    end
    Prob_Host=[ vcat(zeros(1, L)...) for j in 1:(N_host)]
    #Avaraging
    for n in 1:N_seed
        [Prob_Host[j].+=Host[j][n]./N_seed for j in 1:(N_host-1)]
    end
    # Due to normazability considtions
    Prob_Host[end]= 1 .- reduce((x, y) -> x .+ y, Prob_Host[1:end-1]) 
    return Prob_Host
end

function Random_Dataset(L, probabilities)
    N=length(L)
    dist = Categorical(probabilities)
    return [join(dna_alphabet[rand(dist)] for _ in 1:L[i]) for i in 1:N] 
end

function train_ordered_sets(Train_Ordered_HgV, Lmotifs, Lseqs)
    Models=[]
    for j in 1:N_host
        models=[]
        [push!(models, Main.MaxEntNucleotideBiases.fitmodel(Train_Ordered_HgV[j][n], Lmotifs, Lseqs)) for n in 1:N_seed]
        push!(Models, models)
    end
    return Models
end


function train_ordered_sets_HaV(Train_Ordered_HaV, Lmotifs, Lseqs)
    M=[]
    for j in 1:N_host
        Models=[]
        for k in 1:N_virus
            models=[]
            [push!(models, Main.MaxEntNucleotideBiases.fitmodel(Train_Ordered_HaV[j][k][n], Lmotifs, Lseqs)) for n in 1:N_seed]
            push!(Models, models)
        end
        push!(M, Models)
    end
    return M
end

function train_ordered_sets_H(Train_Ordered_H, Lmotifs, Lseqs)
    Models=[]
    for j in 1:N_host
            models=[]
            [push!(models, Main.MaxEntNucleotideBiases.fitmodel(Train_Ordered_H[j][n], Lmotifs, Lseqs)) for n in 1:N_seed]
            push!(Models, models)
    end
    return Models
end


function order_HgV(Host_Virus, k)
    Set=[]
    for j in 1:N_host
        set=[]
        for n in 1:N_seed
            push!(set, Host_Virus[(N_virus*N_seed)*(j-1)+N_seed*(k-1)+n])
        end
        push!(Set, set)
    end
    return Set
end

function order_HaV(Host_Virus)
    Set=[]
    for j in 1:N_host
        SET=[]
        for k in 1:N_virus
            set=[]
            for n in 1:N_seed
                push!(set, Host_Virus[(N_virus*N_seed)*(j-1)+N_seed*(k-1)+n])
            end
            push!(SET, set)
        end
        push!(Set, SET)
    end
    return Set
end

function order_H(Host)
    Set=[]
    for j in 1:N_host
        set=[]
        for n in 1:N_seed
            push!(set, Host[N_seed*(j-1)+n])
        end
        push!(Set, set)
    end
    return Set
end